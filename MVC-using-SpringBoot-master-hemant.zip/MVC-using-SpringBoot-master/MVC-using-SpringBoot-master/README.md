# MVC-using-SpringBoot  
This project includes simple implementation of MVC on SpringBoot using ThymeLeaf as View Template Engine.
